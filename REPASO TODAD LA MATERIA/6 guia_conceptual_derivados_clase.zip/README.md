# Guía conceptual de derivados vistos en clase

Proyecto LaTeX compilable con XeLaTeX + Biber.

## Compilación

```bash
latexmk -xelatex -interaction=nonstopmode main.tex
```

## Contenido

- Derivados lineales: forwards, futuros y swaps.
- Opciones vanilla y paridad put-call.
- Paquetes, estrategias y sintéticos.
- Notas estructuradas.
- Opciones binarias, gap, chooser, compuestas y forward-start.
- Opciones asiáticas aritméticas y geométricas, lookback y barrera.
- Opciones multi-activo: exchange, basket, rainbow y quanto.
- Derivados de tasas: bonos, caplets, floorlets, caps, floors, swaptions y modelos de tasa corta.
- Derivados de crédito: CDS, binary CDS, forward CDS, CDS options, CDO, tranches, índices, nth-to-default y Credit VaR.
- Opciones reales.
