# Resumen de Derivados Exóticos

Proyecto LaTeX listo para compilar con XeLaTeX.

## Compilación

```bash
xelatex main.tex
xelatex main.tex
```

## Contenido

- Glosario y marco neutral al riesgo
- Derivados vanilla: forwards, opciones, paridad, Black-Scholes, griegas
- Opciones exóticas: asiáticas, lookback, barrera, binarias, compuestas, notas estructuradas
- Derivados de crédito: supervivencia, intensidad, CDS, forward CDS, CDS options
- Multiname: índices CDS, k-th-to-default, correlación, CDO sintético, tranches
- Modelos de tasa corta: Vasicek, CIR, Hull-White, opciones sobre bonos
- Mapa rápido, errores típicos y pseudocódigo
