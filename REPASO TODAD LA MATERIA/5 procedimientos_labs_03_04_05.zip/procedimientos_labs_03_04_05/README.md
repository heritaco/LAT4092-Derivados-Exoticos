# Procedimientos Labs 03, 04 y 05

Proyecto LaTeX con procedimientos de los laboratorios de los sources 03, 04 y 05.

- `main.tex`: fuente LaTeX.
- `main.pdf`: PDF compilado.

No ejecuta Solver, Excel, Bloomberg, simulaciones ni consultas externas; deja esos puntos como algoritmos o plantillas matemáticas.
