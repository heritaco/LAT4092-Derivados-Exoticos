# Formulario por tipo de opción

Proyecto LaTeX compilable para repasar fórmulas de derivados vanilla, opciones exóticas, tasas y crédito.

## Compilar

```bash
pdflatex main.tex
pdflatex main.tex
```

El archivo principal es `main.tex`.
