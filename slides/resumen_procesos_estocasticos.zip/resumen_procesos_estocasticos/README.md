# Resumen de repaso: Procesos estocásticos

Contenido del paquete:

- `main.tex`: documento principal en LaTeX.
- `biblio.bib`: bibliografía separada en BibLaTeX estilo APA.
- `README.md`: instrucciones.

## Compilación recomendada

Con TeX Live / MacTeX:

```bash
pdflatex main.tex
biber main
pdflatex main.tex
pdflatex main.tex
```

También puedes abrir `main.tex` en Overleaf y compilar con `pdfLaTeX + biber`.
