# Laboratorios teóricos de derivados

Proyecto LaTeX separado del formulario de opciones.

Archivos:
- `main.tex`: fuente LaTeX.
- `main.pdf`: PDF compilado.

Estructura:
- Cada laboratorio comienza en página nueva con `\newpage`.
- Cada problema es una `\subsection`.
- Los ejercicios son teóricos y explicativos; priorizan construcción de payoff, mecanismo financiero, fórmula y errores comunes.
